<%@ page import="java.util.*" %>
<!-- 
 Author: Hugo Ramirez 
 Project: assignment 6.3
 Created: 04/18/2026 project part 1
 Description: Index file with a form to select a movie ID and display the corresponding record and all records from the database.
 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CSD430 - Hugo's Project Index</title>
</head>
<body>

  <jsp:useBean id='myDB' class='database.DbBean' />

  <h2>Movie Database</h2>

  <%
  if (request.getMethod().equals("GET")) {

      out.print(myDB.formGetPK("index.jsp"));

  }
  %>

  <%
  if (request.getMethod().equals("POST")) {

      out.print(myDB.formGetPK("index.jsp"));

      String movieIdParam = request.getParameter("movie_id");

      out.print(myDB.read(Integer.parseInt(movieIdParam)));

      out.println("<br />");

      out.print(myDB.readAll());

  }
  %>

</body>
</html>
