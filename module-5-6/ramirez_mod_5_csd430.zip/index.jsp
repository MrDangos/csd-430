<%@ page import="java.util.*" %>
<!-- 
 Author: Hugo Ramirez 
 Project: index.jsp
 Created: 04/18/2026
 Description: Index file that links to the CRUD files
 -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>CSD430 - Hugo's Project Index</title>

</head>
<body>
    <a href="Ramirez_createTable.php">Create Table (createTable.jsp)</a>
    <a href="Ramirez_populateTable.php">Populate Table (populateTable.jsp)</a>
    <a href="Ramirez_dropTable.php">Drop Table (dropTable.jsp)</a>
</body>
</html>
