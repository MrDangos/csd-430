<!-- 
 Author: Hugo Ramirez 
 Project: Ramirez_createTable.php
 Created: 04/18/2026
 Description: PHP script to create a table in a MySQL database.
 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $servername = "localhost";
        $username = "student1";
        $password = "pass";
        $dbname = "csd430";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
        }

        // sql to create table
        $sql = "CREATE TABLE hugo_movies_data (
            movie_id     INT          NOT NULL AUTO_INCREMENT,
            title        VARCHAR(100) NOT NULL,
            director     VARCHAR(100) NOT NULL,
            release_year INT          NOT NULL,
            genre        VARCHAR(50)  NOT NULL,
            imdb_rating  DECIMAL(3,1) NOT NULL,
            PRIMARY KEY (movie_id))";

        if ($conn->query($sql) === TRUE) {
        echo "Table created successfully";
        } else {
        echo "Error creating table: " . $conn->error;
        }

        $conn->close();
    ?>
</body>
</html>