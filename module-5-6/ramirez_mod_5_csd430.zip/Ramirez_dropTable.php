<!-- 
 Author: Hugo Ramirez 
 Project: Ramirez_dropTable.php
 Created: 04/18/2026
 Description: PHP script to drop a table in a MySQL database.
 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>populate table</title>
</head>
<body>
    <?php
        $servername = "localhost";
        $username = "student1";
        $password = "pass";
        $dbname = "csd430";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "DROP TABLE IF EXISTS hugo_movies_data";

        if ($conn->query($sql) === TRUE) {
            echo "Table hugo_movies_data dropped successfully.";
        } else {
            echo "Error dropping table: " . $conn->error;
        }

        $conn->close();

    ?>
</body>
</html>