<!-- 
 Author: Hugo Ramirez 
 Project: Ramirez_populateTable.php
 Created: 04/18/2026
 Description: PHP script to populate a table in a MySQL database.
 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>populate table</title>
</head>
<body>
    <?php
        $servername = "localhost";
        $username = "student1";
        $password = "pass";
        $dbname = "csd430";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // sql to populate table
        $sql = "INSERT INTO hugo_movies_data (title, director, release_year, genre, imdb_rating) VALUES
        ('1917',                           'Sam Mendes',         2019, 'War',       8.3),
        ('Redline',                        'Takeshi Koike',      2009, 'Animation', 7.6),
        ('Weathering With You',            'Makoto Shinkai',     2019, 'Animation', 7.5),
        ('Inglourious Basterds',           'Quentin Tarantino',  2009, 'War',       8.3),
        ('Baby Driver',                    'Edgar Wright',       2017, 'Action',    7.6),
        ('Jurassic Park',                  'Steven Spielberg',   1993, 'Adventure', 8.2),
        ('Godzilla Minus One',             'Takashi Yamazaki',   2023, 'Sci-Fi',    7.9),
        ('Mobile Suit Gundam: Narrative',  'Shunichi Yoshizawa', 2018, 'Animation', 6.5),
        ('John Wick',                      'Chad Stahelski',     2014, 'Action',    7.4),
        ('The Fast and the Furious',       'Rob Cohen',          2001, 'Action',    6.8);";

        if ($conn->query($sql) === TRUE) {
        echo "Table populated successfully";
        } else {
        echo "Error populating table: " . $conn->error;
        }

        $conn->close();
    ?>
</body>
</html>